import 'package:nean_verg_s_application2/core/app_export.dart';

class ApiClient {}
